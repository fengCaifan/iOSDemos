//
//  ActivityViewController.swift
//  FordShow
//
//  Created by xinyue on 2019/5/29.
//  Copyright © 2019 weicheng. All rights reserved.
//

import UIKit

class ActivityViewController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var newItemBtn: UIButton!
    @IBOutlet weak var pastItemBtn: UIButton!
    
    var isVideo: Bool = false
    
    var index = 0 {
        didSet {
        }
    }
    
    var dataSource:[SubjectInfo] = [] {
        didSet{
            self.configData()
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        collectionView.register(UINib(nibName: "ActiivityCollectionViewCell", bundle: nil),
                                forCellWithReuseIdentifier: "ActiivityCollectionViewCell")
        collectionView.backgroundColor = UIColor.clear.withAlphaComponent(0)
        
        videoBtnItemAction(self.newItemBtn)
    }
    
    
    func configData() {
        self.collectionView.reloadData()
    }
    

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView.reloadData()
    }
    
    @IBAction func videoBtnItemAction(_ sender: Any) {
        collectionView.scrollToItem(at: IndexPath(item: 0, section: 0), at: .centeredHorizontally, animated: true)
        self.newItemBtn.setBackgroundImage(UIImage(named: "tab_select"), for: .normal)
        self.pastItemBtn.setBackgroundImage(nil, for: .normal)
        self.newItemBtn.setTitleColor(UIColor.white, for: .normal)
        self.pastItemBtn.setTitleColor(UIColor.hexString(hex: "848484"), for: .normal)
        
    }
    
    @IBAction func picBtnItemAction(_ sender: Any) {
        self.pastItemBtn.setBackgroundImage(UIImage(named: "tab_select"), for: .normal)
        self.newItemBtn.setBackgroundImage(nil, for: .normal)
        
        self.pastItemBtn.setTitleColor(UIColor.white, for: .normal)
        self.newItemBtn.setTitleColor(UIColor.hexString(hex: "848484"), for: .normal)
        
        collectionView.scrollToItem(at: IndexPath(item: 1, section: 0), at: .centeredHorizontally, animated: true)
    }
    
}

extension ActivityViewController: UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ActiivityCollectionViewCell",
                                                      for: indexPath) as! ActiivityCollectionViewCell
        if indexPath.row < self.dataSource.count {
            let m = self.dataSource[indexPath.row]
            let style: ColumnStyle = (!isVideo && indexPath.row == 0) ? .double : .single
            cell.set(m, style: style, isVideo: isVideo, didSelectItem: { [unowned self] model in
                
                let detail = ActivityDetailController()
                detail.view.frame = CGRect(x: 0, y: 0, width: contentWidth, height: self.view.bounds.height)
                detail.isVideo = self.isVideo
                detail.source = model
                
                
                self.addChild(detail)
                self.view.addSubview(detail.view)
                
//                self.present(detail, animated: true, completion: nil)
            })
        }
        
        return cell
    }
    
}

extension ActivityViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.bounds.width, height: view.bounds.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}
