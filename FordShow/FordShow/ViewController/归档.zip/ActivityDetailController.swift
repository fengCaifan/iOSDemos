//
//  ActivityDetailController.swift
//  FordShow
//
//  Created by xinyue on 2019/5/29.
//  Copyright © 2019 weicheng. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class ActivityDetailController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var titleBtn: UIButton!
    
//    @IBOutlet weak var switchBtn: UIButton!
    
    var isVideo: Bool = false {
        didSet{
//            if self.isVideo {
//                self.switchBtn.setImage(UIImage(named: "go_pic"), for: .normal)
//            }else{
//                self.switchBtn.setImage(UIImage(named: "go_video"), for: .normal)
//            }
        }
    }
    
    var source:SubjectObjc? {
        didSet{
            self.configData()
        }
    }
    
    
    var dataSource:[(type:String,title:String,img:UIImage,name:String)] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = UIColor.clear.withAlphaComponent(0)
        collectionView.contentInset = UIEdgeInsets(top: 200, left: 0, bottom: 0, right: 0)
        collectionView.register(UINib(nibName: "ActivityListPicCollectionCell", bundle: nil), forCellWithReuseIdentifier: "ActivityListPicCollectionCell")
    }
    
    
    func configData() {
        
        if let dsource = self.source {
            self.titleBtn.setTitle(dsource.site, for: .normal)
            //
            self.dataSource.removeAll()
            if self.isVideo {
                for videoinfo in dsource.videotuples {
                    if let img = getCoverimg(name: videoinfo.1) {
                        self.dataSource.append((type: "video", title: videoinfo.0, img:img , name: videoinfo.1))
                    }
                }
            }else{
                for imginfo in dsource.imgtuples {
                    if let img = UIImage(named: imginfo) {
                        self.dataSource.append((type: "img", title: "", img:img , name: imginfo))
                    }
                }
            }
            
            self.collectionView.reloadData()
        }
        
    }
    
    //获取视频封面图
    func getCoverimg(name:String)->UIImage?{
        if let filePath = Bundle.main.path(forResource: name, ofType: "mp4") {
            let url = URL(fileURLWithPath: filePath)
            let asset:AVAsset = AVAsset(url: url)
            //生成视频截图
            let generator = AVAssetImageGenerator(asset: asset)
            generator.appliesPreferredTrackTransform = true
            let time = CMTimeMakeWithSeconds(Float64(0.0), preferredTimescale: 600)
            var actualTime:CMTime = CMTimeMake(value: Int64(0), timescale: 0)
            
            if let imageRef:CGImage = try? generator.copyCGImage(at: time, actualTime: &actualTime) {
                return UIImage(cgImage: imageRef)
            }
        }
        return nil
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        modalTransitionStyle = .crossDissolve
        modalPresentationStyle = .custom
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        print("ActivityDetailController deinit")
    }
    @IBAction func closeAction(_ sender: Any) {
        self.view.removeFromSuperview()
        self.removeFromParent()
    }
    
    
    @IBAction func backBtnAction(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
}

extension ActivityDetailController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.dataSource.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell:ActivityListPicCollectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ActivityListPicCollectionCell", for: indexPath) as! ActivityListPicCollectionCell
        
        if indexPath.row < self.dataSource.count {
            let obj = self.dataSource[indexPath.row]
            
            if self.isVideo {
                cell.titleHeight.constant = 60
                cell.playItem.isHidden = false
                cell.titleLabel.text = obj.title
                cell.pic.image = obj.img
                
            }else{
                cell.titleHeight.constant = 0
                cell.playItem.isHidden = true
                cell.titleLabel.text = ""
                cell.pic.image = obj.img
            }
        }
        
        return cell
    }

}

extension ActivityDetailController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if self.isVideo {
            let w = view.bounds.width - 100
            return CGSize(width: w, height: w/2.0)
        }else{
            let w = (view.bounds.width)/2 - 50
            return CGSize(width: w, height: w/2.0)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // TODO: 进入图片浏览器或者视频播放器
        if indexPath.row < self.dataSource.count {
            let obj = self.dataSource[indexPath.row]
        
            if self.isVideo {
                let vc = FSVideoPlayerVC(frame:CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height))
                let name = obj.name
                let filePath = Bundle.main.path(forResource: name, ofType: "mp4")
                vc.url = URL(fileURLWithPath: filePath!)
                guard let rootVC = UIApplication.shared.keyWindow?.rootViewController else {
                    return
                }
                rootVC.addChild(vc)
                rootVC.view.addSubview(vc.view)
                rootVC.view.bringSubviewToFront(vc.view)
            }else{
                if let imgs = self.source?.imgtuples {
                    let previewVC = ImagePreviewVC(frame:UIScreen.main.bounds,images: imgs, index: indexPath.row)
                    guard let rootVC = UIApplication.shared.keyWindow?.rootViewController else {
                        return
                    }
                    rootVC.addChild(previewVC)
                    rootVC.view.addSubview(previewVC.view)
                    rootVC.view.bringSubviewToFront(previewVC.view)
                }
            }
        }
        
    }
    
}
