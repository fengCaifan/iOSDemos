//
//  SubjectController.swift
//  FordShow
//
//  Created by 冯才凡 on 2019/5/8.
//  Copyright © 2019 weicheng. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

//专题活动
class SubjectController: UIViewController {
    
    @IBOutlet weak var switchButton: UIButton!
    @IBOutlet weak var coverImageView: UIImageView!
    var index = 0 {
        didSet {
            emptyImageView.image = UIImage(named: index == 2 ? "empty_txz": "empty_mustang")
        }
    }
    
    var isVideo = false {
        didSet{
            if self.isVideo {
                self.switchButton.setImage(UIImage(named: "go_pic"), for: .normal)
            }else{
                self.switchButton.setImage(UIImage(named: "go_video"), for: .normal)
            }
        }
    } // TODO: 临时变量，后面要根据模型判断
        
    @IBOutlet weak var emptyImageView: UIImageView!
    
    var model: SubjectModel?{
        didSet{
            if let m = model {
                for imgname in m.img {
                    //先添加图片
                    if let img = UIImage(named: imgname) {
                        self.images.append((type: "img", img: img, name:imgname))
                    }
                }
                
                for name in m.video {
                    //video
                    if let img = self.getCoverimg(name: name) {
                        self.images.append((type: "video", img: img, name:name))
                    }
                }
                
            }
            let isEmpty = (model == nil || (model?.img.count == 0) && (model?.video.count == 0))
            emptyImageView.isHidden = !isEmpty
        }
    }
    
    var images:[(type:String,img:UIImage,name:String)] = []
    
    
    //
    var subobjc:[SubjectObjc]? {
        didSet{
            self.configData()
        }
    }
    
    
    
    @IBOutlet weak var backGroundImage: UIImageView!
    
    @IBAction func enterActivity(_ sender: Any) {
        addChild(pictureController)
        view.addSubview(pictureController.view)
        view.bringSubviewToFront(switchButton)
        switchButton.isHidden = false
        self.isVideo = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        switchButton.isHidden = true
        view.backgroundColor = UIColor.clear
    }
    
    //专题
    lazy var pictureController: ActivityViewController = {
        let content = ActivityViewController()
        content.isVideo = false
        content.view.frame = CGRect(x: 0, y: 0, width: contentWidth, height: UIScreen.main.bounds.height)
        return content
    }()
    
    //专题
    lazy var videoController: ActivityViewController = {
        let content = ActivityViewController()
        content.isVideo = true
        content.view.frame = CGRect(x: 0, y: 0, width: contentWidth, height: UIScreen.main.bounds.height)
        return content
    }()
    
    @IBAction func switchAction(_ sender: Any) {
        let targetRect = CGRect(x: 0, y: 0, width: contentWidth, height: view.frame.height)
        let originRect = CGRect(x: 0, y: view.frame.height, width: contentWidth, height: view.frame.height)
        let origin1Rect = CGRect(x: 0, y: -view.frame.height, width: contentWidth, height: view.frame.height)
        
        isVideo = !isVideo
        
        if !isVideo {
            addChild(pictureController)
            view.addSubview(pictureController.view)
            pictureController.view.frame = originRect
        }else{
            addChild(videoController)
            view.addSubview(videoController.view)
            videoController.view.frame = origin1Rect
        }
        
        UIView.animate(withDuration: 0.35,
                       delay: 0,
                       usingSpringWithDamping: 0.3,
                       initialSpringVelocity: 0.5,
                       options: UIView.AnimationOptions.curveLinear, 
        animations: { [unowned self] in
            if !self.isVideo {
                self.pictureController.view.frame = targetRect
                self.videoController.view.frame = origin1Rect
            }else{
                self.videoController.view.frame = targetRect
                self.pictureController.view.frame = originRect
            }
                                    
        }, completion: { [unowned self] _ in
            
            if !self.isVideo {
                self.videoController.view.removeFromSuperview()
                self.videoController.removeFromParent()
            }else{
                self.pictureController.view.removeFromSuperview()
                self.pictureController.removeFromParent()
            }
            self.view.bringSubviewToFront(self.switchButton)
        })
        
        
    }
    
    //获取视频封面图
    func getCoverimg(name:String)->UIImage?{
        if let filePath = Bundle.main.path(forResource: name, ofType: "mp4") {
            let url = URL(fileURLWithPath: filePath)
            let asset:AVAsset = AVAsset(url: url)
            //生成视频截图
            let generator = AVAssetImageGenerator(asset: asset)
            generator.appliesPreferredTrackTransform = true
            let time = CMTimeMakeWithSeconds(Float64(0.0), preferredTimescale: 600)
            var actualTime:CMTime = CMTimeMake(value: Int64(0), timescale: 0)
            
            if let imageRef:CGImage = try? generator.copyCGImage(at: time, actualTime: &actualTime) {
                return UIImage(cgImage: imageRef)
            }
        }
        return nil
    }
    
    func configData() {
        //
        if let subobjc0 = self.subobjc  {
            var newsubjects:[SubjectObjc] = []
            var pastsubjects:[SubjectObjc] = []
            
            for model in subobjc0 {
                if model.type == .new {
                    newsubjects.append(model)
                }else{
                    pastsubjects.append(model)
                }
            }
            
            
            var dataSource:[SubjectInfo] = []
            dataSource.append(SubjectInfo(type: .new, subjects: newsubjects))
            dataSource.append(SubjectInfo(type: .past, subjects: pastsubjects))
            
            self.videoController.dataSource = dataSource
            self.pictureController.dataSource = dataSource
            
        }
        
    }


}
